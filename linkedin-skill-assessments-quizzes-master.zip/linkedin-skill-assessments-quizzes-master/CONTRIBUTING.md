## When I want to create PR request

- Any changes or new questions even without an answer can be a great help! Please do not hesitate to create any new PR, as we do not have a strict requirements for that matter.

## If I found something weird or incorrect, what should I do?

- You can create a PR to your liking and add any improvements, so we can quickly merge it

## How can I get on the list of contributors?

- after your PR is merged, you will be automatically become a contributor and will be appeared in the Readme.md as the contributor.

## PLEASE

add explanation (`or reference link`) to your answers. That will help anyone to better learn concepts they might not have a great understanding about.
